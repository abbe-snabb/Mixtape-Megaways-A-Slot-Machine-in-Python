import slot_gui

if __name__ == "__main__":
    slot_gui.main()